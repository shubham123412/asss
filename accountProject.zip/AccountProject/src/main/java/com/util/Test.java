package com.util;

public class Test {
	// IM ON MUTE
	public static void main(String[] args) {
		Father fath = new Father();
		Child ch = new Child(fath);
		ch.dadyIWantChocolate();

	}
}

class Father
{
	Chocolate purchase() {
		Chocolate ch = ChocolateShop.getIt();
		return ch;
	}
}

class Child
{
	Father ref;
	
	Child(Father f) {
		ref = f;
	}
	
	
	void dadyIWantChocolate() {
		Chocolate ch = ref.purchase();
		ch.fun();
	}
}

class ChocolateShop
{
	static Chocolate getIt() {
		// some process..
		ChocolateFactory chFact = new ChocolateFactory();
		Chocolate ch = chFact.getChocolate();
		return ch;
	}
}

class Chocolate
{
	void fun() {
		System.out.println("eat and have fun...");
	}
}

class ChocolateFactory
{
	Chocolate getChocolate() {
		//some process here
		return new Chocolate();
	}
}

