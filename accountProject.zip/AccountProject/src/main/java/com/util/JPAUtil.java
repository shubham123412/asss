package com.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/*class MyThread extends Thread
{
	EntityManagerFactory  ref;
	
	MyThread (	EntityManagerFactory  r)
	{
		ref = r;
	}
	public void run() {
		ref.close();
	}
}

A a = new A();
A b = new A();
A c = new A();
A.foo();
A.foo();
A.foo();

a.fun();
b.fun();
c.fun();

1 ..
2 ..
3 - ..
4 - conscious mind
5 - un conscious mind
6 ..
7 ..




*/

class A
{
	static {
		
	}
	
	A()
	{
		
	}
	void fun() { }
	
}
class client {	void test() { 	Lion myLion = JPAUtil.getLion(); } }
class Lion   {  void roar() { 	System.out.println("Lion is roaring...");
	}
}
class Jungle { 	static Lion trapAndGetALion() { //do some trick/trap activity here...and
		return new Lion();
	}
}
public class JPAUtil {
	private static Lion lion; // null reference
	public static Lion getLion() {
		return lion; //just a reference, where is new?
	}
	// this block is executed automatically when the class
	static { //JpaUtil is loaded ..that too only one time
		lion = Jungle.trapAndGetALion();
	} //u dont have to bother to run the static block

				        //SessionFactory
	private static EntityManagerFactory entityManagerFactory;
	
	public static EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}
	
	static 
	{
		entityManagerFactory = Persistence.createEntityManagerFactory("Hibernate-JPA");//META-INF/persistence.xml
	//	MyThread m = new MyThread(entityManagerFactory);
//		m.start();
	//	Runtime.getRuntime().addShutdownHook(m);
		
		Runtime.getRuntime().addShutdownHook(	
				
				new Thread()
				{
						public void run() {
							entityManagerFactory.close();
						}
				}
		);

	}
	
	
}
