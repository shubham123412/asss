package com.onetomanybi;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import com.util.BaseDao;

public class customertest {
	


		@Test
		public void testCase1a()
		{
			//Department dept1 = new Department(10,"Admin","Andheri");
			
			BaseDao dao = new BaseDao();
			
			Employee project = new Employee();
			
			project.setEmpName("rahuul2");		
			project.setEmployeeid(1121);		
			
			
			
			List<Customer1> members= new LinkedList<Customer1>();
			
			Customer1 member1 = new Customer1();
			//Customer1 member2 = new Customer1();
			//Customer1 member3 = new Customer1();
			
			member1.setCustomerName("rohit11");		member1.setCustomerid(10011); 		member1.setEmployee(project);
			//member2.setCustomerName("aman2");		member2.setCustomerid(1011);		//member2.setProject(project);
			//member3.setCustomerName("lala3");		member3.setCustomerid(1021); 		//member3.setProject(project);
			
			members.add(member1); //eachmember is added to the set
		//	members.add(member2); //eachmember is added to the set
		//	members.add(member3); //eachmember is added to the set
			
			
			project.setCustomer1s(members); //finally teh set is added to the project
			
			dao.persist(project); //persisting the project will add the members too
			
			
			
		}


}
