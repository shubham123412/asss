package com.onetomanybi;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the EMPLOYEE database table.
 * 
 */
@Entity
@NamedQuery(name="Employee.findAll", query="SELECT e FROM Employee e")
public class Employee implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long employeeid;

	@Column(name="EMP_NAME")
	private String empName;

	//bi-directional many-to-one association to Customer1
	@OneToMany(mappedBy="employee", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	private List<Customer1> customer1s;

	public Employee() {
	}

	public long getEmployeeid() {
		return this.employeeid;
	}

	public void setEmployeeid(long employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmpName() {
		return this.empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public List<Customer1> getCustomer1s() {
		return this.customer1s;
	}

	public void setCustomer1s(List<Customer1> customer1s) {
		this.customer1s = customer1s;
	}

	public Customer1 addCustomer1(Customer1 customer1) {
		getCustomer1s().add(customer1);
		customer1.setEmployee(this);

		return customer1;
	}

	public Customer1 removeCustomer1(Customer1 customer1) {
		getCustomer1s().remove(customer1);
		customer1.setEmployee(null);

		return customer1;
	}

}
