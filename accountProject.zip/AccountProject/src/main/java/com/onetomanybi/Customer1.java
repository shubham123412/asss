package com.onetomanybi;


import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CUSTOMER1 database table.
 * 
 */
@Entity
@NamedQuery(name="Customer1.findAll", query="SELECT c FROM Customer1 c")
public class Customer1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long customerid;

	@Column(name="CUSTOMER_NAME")
	private String customerName;

	//bi-directional many-to-one association to Employee
	@ManyToOne
	@JoinColumn(name="EMPLOYEEID")
	private Employee employee;

	public Customer1() {
	}

	public long getCustomerid() {
		return this.customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Employee getEmployee() {
		return this.employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}