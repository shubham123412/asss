package com.accounts;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="bank_accounts")
public class BankAccount {

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	@Id
	@GeneratedValue
	@Column(name="acc_no")
	private int accountNumber;
	
	@Column(name="acc_name", length = 20)
	private String accountHolder;
	
	@Column(name="acc_bal")
	private double accountBalance;
	
	//@Column(name="acc_pin")
	@Transient // would not be persisted
	private int pinNumber;
	
	//except static and transient all fields are persited

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
}
