package com.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity(name = "Employee1")
public class Employee {

	@Id
	@GeneratedValue
	private int id;
	
	@Column(length=15) 
	private String name;
	
	//default lazy behavior : eager
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cubicle_id_fk", unique = true) //foreign key column is not a table's data member
	private Cubicle assignedCubicle;

	public int getId() {
		System.out.println("getId() for Employee");
		return id;
	}

	public void setId(int id) {
		System.out.println("setId(int) for Employee");
		this.id = id;
	}

	public String getName() {
		System.out.println("getName() for Employee");
		return name;
	}

	public void setName(String name) {
		System.out.println("setName(String) for Employee");
		this.name = name;
	}

	public Cubicle getAssignedCubicle() {
		System.out.println("Cubicle getAssignedCubicle() for Employee");
		return assignedCubicle;
	}

	public void setAssignedCubicle(Cubicle assignedCubicle) {
		System.out.println("void setAssignedCubicle(Cubicle c) for Employee");
		this.assignedCubicle = assignedCubicle;
	}
	
	
}
