package com.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity(name = "Cubicle1")
public class Cubicle {

	// 1 2 3 
	
	@Id
	@GeneratedValue
	private int id;
	
	@Column(length=15) 
	public String floor;
	
	//mappedBy specifies who owns the relationship
	@OneToOne(mappedBy = "assignedCubicle")
	private Employee residentEmployee;

	public int getId() {
		System.out.println("getId() for Cubicle");
		return id;
	}

	public void setId(int id) {
		System.out.println("setId() for Cubicle");
		this.id = id;
	}

	public String getFloor() {
		System.out.println("getFloor() for Cubicle");
		return floor;
	}

	public void setFloor(String floor) {
		System.out.println("setFloor() for Cubicle");
		this.floor = floor;
	}

	public Employee getResidentEmployee() {
		System.out.println("Employee getResidentEmployee() for Cubicle");
		return residentEmployee;
	}

	public void setResidentEmployee(Employee residentEmployee) {
		System.out.println("void setResidentEmployee(Employee e) for Cubicle");
		this.residentEmployee = residentEmployee;
	}
	
	
	
}
