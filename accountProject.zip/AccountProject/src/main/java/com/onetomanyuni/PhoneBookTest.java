package com.onetomanyuni;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.util.BaseDao;

public class PhoneBookTest {

	@Test
	public void testCase1() {
		PhoneBook phBook = new PhoneBook();
		phBook.setName("My PhoneBook");
		
		Set<Entry> entries = new HashSet<Entry>();
		entries.add(new Entry("Entry1", 12345, "entry1@domain.com"));
		entries.add(new Entry("Entry2", 12346, "entry2@domain.com"));
		entries.add(new Entry("Entry3", 12347, "entry3@domain.com"));
		entries.add(new Entry("Entry4", 12348, "entry4@domain.com"));
		entries.add(new Entry("Entry5", 12349, "entry5@domain.com"));
		phBook.setEntries(entries);
		
		BaseDao dao = new BaseDao();
		dao.merge(phBook);
	}
	
	@Test
	public void testCase() {
		PhoneBook phBook = new PhoneBook();
		phBook.setName("Your PhoneBook");
		
		Set<Entry> entries = new HashSet<Entry>();
		entries.add(new Entry("Entry6", 62345, "entry6@domain.com"));
		entries.add(new Entry("Entry7", 72346, "entry7@domain.com"));
		entries.add(new Entry("Entry8", 82347, "entry8@domain.com"));
		entries.add(new Entry("Entry9", 92348, "entry9@domain.com"));
		entries.add(new Entry("Entry0", 12349, "entry0@domain.com"));
		phBook.setEntries(entries);
		
		BaseDao dao = new BaseDao();
		dao.merge(phBook);
	}
	
	@Test
	public void testCase2() {
		BaseDao dao = new BaseDao();
		PhoneBook phBook = (PhoneBook) dao.find(PhoneBook.class, 44);
		System.out.println(phBook); //toString()
		System.out.println(phBook.getEntries()); //toString()
	}

	@Test
	public void testCase3() {
		BaseDao dao = new BaseDao();		
		Entry newEntry = new Entry("New Entry", 99999, "newEntry@domain.com");
		PhoneBook phBook = (PhoneBook) dao.find(PhoneBook.class, 50);
		phBook.getEntries().add(newEntry);
		dao.merge(phBook);
	}

}
