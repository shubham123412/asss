package com.onetomanyuni;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
/*
 * create table Entry
 * (
 *    id number primary key,
 *    name varchar2(20),
 *    number number,
 *    email varchar2(20)
 *  )
 */
public class Entry {

	

	@Id
	@GeneratedValue
	private int id;
	
	@Column(length=20)
	private String name;
	
	private int phoneNum;
	
	@Column(length=20)
	private String email;	
	
	public Entry() {
	}

	public Entry(String name, int phone, String email) {
		this.name = name;
		this.phoneNum= phone;
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(int phoneNum) {
		this.phoneNum = phoneNum;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Entry [id=" + id + ", name=" + name + ", phoneNum=" + phoneNum
				+ ", email=" + email + "]";
	}
}
